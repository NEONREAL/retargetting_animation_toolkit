import bpy  # type: ignore
from ..constants import get_operator


# Define the operator to snap FK bones to IK bones
class OBJECT_OT_PickObject(bpy.types.Operator):
    bl_idname = get_operator("pick_object")
    bl_description = "fill with selected object"
    bl_label = "Worl"
    bl_options = {"REGISTER", "UNDO"}

    rig: bpy.props.StringProperty()  # type: ignore

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        selected_obj = bpy.context.active_object

        if selected_obj.type != "ARMATURE":
            self.report({"WARNING"}, "Object is not an Armature!")
            return {"FINISHED"}


        props = getattr(context.scene, "move_props", None)
        if props is None:
            context.scene.move_props = bpy.context.scene.move_props  # trigger init
            props = context.scene.move_props

        if hasattr(props, self.rig):
            setattr(props, self.rig, selected_obj)

        return {"FINISHED"}
